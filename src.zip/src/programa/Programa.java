package programa;

import java.util.List;

import dec.Dec;

public class Programa {
	
	
	List<Dec> decs;
	
	public Programa(List<Dec> decs) {
		
		this.decs = decs;
		
	}

}
