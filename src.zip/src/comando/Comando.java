package comando;

abstract public class Comando {

}
