package exp;

public class LiteralInt extends Exp{
	
	int i;
	
	public LiteralInt(int i) {
		this.i = i;

	}

}
