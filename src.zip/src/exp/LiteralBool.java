package exp;

public class LiteralBool extends Exp {
	
	boolean b;

	public LiteralBool(boolean b) {
		
		this.b = b;
		
	}
}
