package exp;

import var.Var;

public class VarExp extends Exp {
	
	Var var;
	public VarExp(Var var) {
	
		this.var = var;
		
	}

}
