package exp;

public class Nao extends Exp{
	
	Exp exp;
	
	public Nao(Exp exp) {
		
		this.exp = exp;
		
	}

}
