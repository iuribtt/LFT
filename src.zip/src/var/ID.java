package var;

public class ID extends Var{


	public String id;

	public ID(String id) {
		
		this.id = id;
		
	}

}
