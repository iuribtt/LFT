package var;

import exp.Exp;

public class IDIndexada extends Var{
	
	Var var;
	Exp exp;
	
	public IDIndexada(Var var, Exp exp) {
		
		this.var = var;
		this.exp = exp;
	
	}

}
