package var;

public abstract class Var {

}
