package tipo;

public abstract class Tipo {

}
