package tipo;

import tBase.TBase;

public class TipoBase extends Tipo{
	
	TBase tBase;
	
	public TipoBase(TBase tBase) {
		
		this.tBase = tBase;
		
	}

}
