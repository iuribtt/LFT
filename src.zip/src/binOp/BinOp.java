package binOp;

public enum BinOp {
	Som , Sub , Mul , Div , Mod , Igual , Menor , E , Ou	

}
