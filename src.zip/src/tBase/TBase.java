package tBase;

public enum TBase {
	Int , Bool , Real
}
