package dec;

public abstract class Dec {

}
