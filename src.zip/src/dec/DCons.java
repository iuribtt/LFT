package dec;

public class DCons extends Dec{
	
	DCons dCons;
	
	public DCons(DCons dCons) {
		
		this.dCons = dCons;
		
	}

}
