package dec;

import dVar.DVar;

public class DecVar extends Dec{
	
	DVar dVar;
	
	public DecVar(DVar dVar) {
		
		this.dVar = dVar;
		
	}

}
