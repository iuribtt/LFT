package dCons;


abstract public class DCons {
	

}
