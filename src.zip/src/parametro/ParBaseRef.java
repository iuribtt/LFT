package parametro;

import tBase.TBase;
import var.ID;

public class ParBaseRef extends Parametro {

	TBase tBase;
	ID id;

	public ParBaseRef(TBase tBase, ID id) {

		this.tBase = tBase;
		this.id = id;

	}

}
