package parametro;

abstract public class Parametro {

}
