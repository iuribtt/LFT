package parametro;

import tBase.TBase;
import var.ID;

public class ParBaseCopia extends Parametro {
	
	TBase tBase;
	ID id;
	
	public ParBaseCopia(TBase tBase, ID id) {
		
		this.tBase = tBase;
		this.id = id;
		
	}

}
