package dVarConsCom;

import dCons.DCons;

public class DC extends DVarConsCom{
	
	DCons dCons;
	
	public DC(DCons dCons) {
		
		this.dCons = dCons;
	}

}
