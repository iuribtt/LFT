package dVarConsCom;

import comando.Comando;

public class Com extends Comando{
	
	Comando comando;
	
	public Com(Comando comando) {
		
		this.comando = comando;
		
	}

}
