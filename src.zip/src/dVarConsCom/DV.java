package dVarConsCom;

import dVar.DVar;

public class DV extends DVarConsCom{
	
	DVar dVar;

	public DV(DVar dVar) {
		
		this.dVar = dVar;
	
	}
}
