package dVarConsCom;

public abstract class DVarConsCom {

}
