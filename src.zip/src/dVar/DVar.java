package dVar;


abstract public class DVar {

}
