package dVar;

import tipo.Tipo;
import var.ID;

public class VarNaoInic extends DVar{
	
	Tipo tipo;
	ID id;
	
	public VarNaoInic(Tipo tipo, ID id) {

		this.tipo = tipo;
		this.id = id;
		
	}

}
